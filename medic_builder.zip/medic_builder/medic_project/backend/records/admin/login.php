<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../config.php";
$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';
$pass = $input['password'] ?? '';
$stmt = $pdo->prepare("SELECT id, name, email, password_hash, role FROM users WHERE email = ? AND role IN ('doctor','admin') LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$user) { echo json_encode(['status'=>'error','message'=>'No user']); exit; }
// verify password (if you store hashed passwords)
if(!password_verify($pass, $user['password_hash'])) { echo json_encode(['status'=>'error','message'=>'Bad']); exit; }
unset($user['password_hash']);
echo json_encode(['status'=>'ok','admin'=>$user]);
?>
