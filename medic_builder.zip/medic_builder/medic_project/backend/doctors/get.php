<?php
require_once "../api/db.php";
require_once "../api/response.php";

$id = $_GET["id"] ?? null;

if (!$id) {
    sendJSON(false, "Doctor ID missing");
}

$result = $conn->query("SELECT * FROM doctors WHERE id='$id'");
$data = $result->fetch_assoc();

sendJSON(true, "Doctor details loaded", $data);
?>
