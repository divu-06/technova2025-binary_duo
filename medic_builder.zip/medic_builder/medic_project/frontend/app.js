// Global frontend functions (MEDIC)
console.log('MEDIC frontend loaded');

// Base API path (relative to frontend folder)
const API_BASE = "../backend/";

// ----------------------
// LOGIN
// ----------------------
async function loginUser() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  if (!email || !password) return alert("Enter email & password");

  try {
    const res = await fetch(API_BASE + "auth/login.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();
    if (res.ok) {
      // store minimal session (in-memory/simple)
      sessionStorage.setItem("medic_user", JSON.stringify(data.user));
localStorage.setItem("medic_user", JSON.stringify(data.user));
window.location.href = "dashboard.html";
    } else {
      alert("Invalid email or password");
    }
  } catch (err) {
    console.error(err);
    alert("Network error");
  }
}
// ----------------------
// LOAD DASHBOARD USER
// ----------------------
function loadDashboard() {
    const user = JSON.parse(localStorage.getItem("medic_user"));

    if (!user) {
        window.location.href = "index.html";
        return;
    }

    document.getElementById("userName").innerText = user.name;
}

// Run only on dashboard.html
if (window.location.pathname.includes("dashboard.html")) {
    loadDashboard();
}

// ----------------------
// LOGOUT
// ----------------------
// ----------------------
// LOGOUT
// ----------------------
function logout() {
  sessionStorage.removeItem("medic_user");
  window.location.href = "login.html";
}

// ----------------------
// UTILS
// ----------------------
function getUser() {
  try { return JSON.parse(sessionStorage.getItem("medic_user")); } catch(e){ return null; }
}

// ----------------------
// APPOINTMENTS
// ----------------------
async function bookAppointment(form) {
  const user_id = form.user_id.value;
  const doctor_id = form.doctor_id.value;
  const datetime = form.datetime.value;
  const reason = form.reason.value;

  const body = { user_id, doctor_id, datetime, reason };
  const res = await fetch(API_BASE + "appointments/create.php", {
    method: "POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify(body)
  });
  const text = await res.text();
  alert("Response: " + text);
}

async function loadAppointments(targetId="appointmentsList") {
  const el = document.getElementById(targetId);
  if(!el) return;
  const res = await fetch(API_BASE + "appointments/list.php");
  const data = await res.json();
  el.innerHTML = "";
  (data.appointments || []).forEach(a=>{
    const div = document.createElement("div");
    div.className = "row card small";
    div.innerHTML = `<b>${a.user_id} → ${a.doctor_id}</b><div>${a.datetime}</div><div>Status: ${a.status}</div>`;
    el.appendChild(div);
  });
}

// ----------------------
// AI SYMPTOM
// ----------------------
async function checkSymptoms(form) {
  const symptoms = form.symptoms.value;
  if(!symptoms) return alert("Type symptoms");
  const res = await fetch(API_BASE + "ai/symptoms_text.php", {
    method: "POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ symptoms })
  });
  const out = await res.text();
  document.getElementById("aiOutput").textContent = out;
}

// ----------------------
// VIDEO
// ----------------------
async function createVideoSession() {
  const res = await fetch(API_BASE + "video/create_session.php", { method: "POST" });
  const data = await res.json();
  alert("Video room: " + data.room + "\nOpen: " + data.url);
}

// ----------------------
// QR
// ----------------------
async function generateQR(form) {
  const user_id = form.user_id.value || getUser()?.id || 1;
  const res = await fetch(API_BASE + "qr/generate.php", {
    method: "POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ user_id })
  });
  const data = await res.json();
  if(data.qr_url){
    document.getElementById("qrImage").src = data.qr_url;
    document.getElementById("qrProfileLink").href = data.profile_url;
  } else {
    alert("Failed to generate QR");
  }
}
// fetch QR for profile (used by profile.html)
async function fetchQRForProfile(userId) {
  try {
    const res = await fetch(API_BASE + "qr/generate.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId })
    });
    return await res.json(); // { qr_url, profile_url, token }
  } catch (e) {
    console.error(e);
    return null;
  }
}

// ----------------------
// SOS
// ----------------------
function sendSOS() {
  if(!navigator.geolocation) return alert("Geolocation not supported");
  navigator.geolocation.getCurrentPosition(async pos => {
    const body = { user_id: getUser()?.id || 1, lat: pos.coords.latitude, lng: pos.coords.longitude, note: "SOS from app" };
    const res = await fetch(API_BASE + "emergency/sos.php", {
      method: "POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    alert("SOS status: " + JSON.stringify(data));
  }, () => alert("Allow location"));
}

// ----------------------
// ONLOAD helpers
// ----------------------
function ensureLoggedIn(redirectTo="login.html"){
  if(!getUser()){
    window.location.href = redirectTo;
    return false;
  }
  return true;
}

document.addEventListener("DOMContentLoaded", ()=>{
  // if any page shows user info
  const user = getUser();
  if(user){
    const uel = document.getElementById("userName");
    if(uel) uel.textContent = user.name || user.email || "User";
  }
});


// ---------- Patient Records ----------
async function loadPatientRecords(){
  const user = getUser();
  if(!user) return;
  const res = await fetch(API_BASE + "records/list.php?user_id=" + user.id);
  const data = await res.json();
  const el = document.getElementById("recordsList");
  el.innerHTML = "";
  if(!data.records || data.records.length===0){
    el.innerHTML = `<div class="card">No records found.</div>`;
    return;
  }
  data.records.forEach(r=>{
    const row = document.createElement("div");
    row.className = "row card";
    row.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <b>${escapeHtml(r.title)}</b>
          <div style="color:var(--muted);font-size:13px">${r.record_date} • ${r.source || ''}</div>
        </div>
        <div>
          <button onclick="viewRecord(${r.id})">View</button>
          <button onclick="editRecord(${r.id})" class="secondary">Edit</button>
          <button onclick="deleteRecord(${r.id})" style="background:#e53e3e">Delete</button>
        </div>
      </div>
      <p style="margin-top:8px">${escapeHtmlSnippet(r.description,180)}</p>
    `;
    el.appendChild(row);
  });
}

function openNewRecordForm(){
  document.getElementById("recordForm").dataset.editId = "";
  document.getElementById("modalTitle").innerText = "Add Medical Record";
  document.getElementById("recordForm").reset();
  document.getElementById("recordModal").style.display = "flex";
}

function closeRecordModal(){
  document.getElementById("recordModal").style.display = "none";
}

async function saveRecord(){
  const form = document.getElementById("recordForm");
  const formData = Object.fromEntries(new FormData(form).entries());
  const editId = form.dataset.editId;
  const user = getUser();
  if(!user) return alert("Not logged in");
  formData.user_id = user.id;

  const url = API_BASE + (editId ? `records/update.php?id=${editId}` : "records/create.php");
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type":"application/json" },
    body: JSON.stringify(formData)
  });
  const out = await res.json();
  if(res.ok || out.status === "success"){
    closeRecordModal();
    loadPatientRecords();
  } else {
    alert("Failed: " + (out.message||JSON.stringify(out)));
  }
}

async function viewRecord(id){
  const res = await fetch(API_BASE + "records/get.php?id=" + id);
  const out = await res.json();
  if(out.record){
    alert(`${out.record.title}\n\nDate: ${out.record.record_date}\nSource: ${out.record.source}\n\n${out.record.description}`);
  } else alert("Not found");
}

async function editRecord(id){
  const res = await fetch(API_BASE + "records/get.php?id=" + id);
  const out = await res.json();
  if(!out.record) return alert("Not found");
  const f = document.getElementById("recordForm");
  f.title.value = out.record.title;
  f.description.value = out.record.description;
  f.record_date.value = out.record.record_date;
  f.source.value = out.record.source;
  f.dataset.editId = id;
  document.getElementById("modalTitle").innerText = "Edit Medical Record";
  document.getElementById("recordModal").style.display = "flex";
}

async function deleteRecord(id){
  if(!confirm("Delete this record?")) return;
  const res = await fetch(API_BASE + "records/delete.php?id=" + id, { method: "POST" });
  const out = await res.json();
  if(out.status === "success") loadPatientRecords();
  else alert("Failed: " + JSON.stringify(out));
}

// small helpers
function escapeHtml(str){ return String(str||"").replace(/[&<>"']/g, s=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[s]); }
function escapeHtmlSnippet(s,n){ s=escapeHtml(s||""); return s.length>n? s.slice(0,n)+"…": s; }
