<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../config.php";

$id = $_GET["id"] ?? null;
if (!$id) {
    http_response_code(400);
    echo json_encode(["error" => "Missing id"]);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM records WHERE id = ?");
$stmt->execute([$id]);
$record = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$record) {
    echo json_encode(["error" => "Record not found"]);
    exit;
}

echo json_encode([
    "status" => "success",
    "record" => $record
]);
