MEDIC Project (auto-generated)
- backend/: PHP endpoints (configure config.php)
- frontend/: basic demo pages
- sql/db_create.sql : run to create DB
Notes: edit backend/config.php to set DB credentials and API keys.
