AI Symptom Checker:
- Text + Image flow
- Placeholder for model integration
