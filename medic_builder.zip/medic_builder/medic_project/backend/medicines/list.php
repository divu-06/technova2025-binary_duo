<?php
require_once "../api/db.php";
require_once "../api/response.php";

$result = $conn->query("SELECT * FROM medicines");

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

sendJSON(true, "Medicine list", $data);
?>
