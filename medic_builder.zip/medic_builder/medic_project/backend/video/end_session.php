<?php
require_once "../api/response.php";

sendJSON(true, "Session ended");
?>
