<?php
require_once __DIR__ . "/../config.php";
$input = json_decode(file_get_contents('php://input'), true);
if(empty($input['user_id'])||empty($input['doctor_id'])||empty($input['datetime'])){ http_response_code(400); echo json_encode(['error'=>'missing']); exit;}
$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
$stmt = $pdo->prepare("INSERT INTO appointments (user_id,doctor_id,datetime,reason,status,created_at) VALUES (?, ?, ?, ?, 'pending', NOW())");
$stmt->execute([$input['user_id'],$input['doctor_id'],$input['datetime'],$input['reason'] ?? null]);
echo json_encode(['status'=>'ok','id'=>$pdo->lastInsertId()]);
?>
