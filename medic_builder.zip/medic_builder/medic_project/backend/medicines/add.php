<?php
require_once "../api/db.php";
require_once "../api/response.php";

$name = $_POST["name"];
$price = $_POST["price"];

if (!$name || !$price) {
    sendJSON(false, "Missing fields");
}

$q = "INSERT INTO medicines (name, price) VALUES ('$name', '$price')";

if ($conn->query($q)) {
    sendJSON(true, "Medicine added");
} else {
    sendJSON(false, "Insert failed");
}
?>
