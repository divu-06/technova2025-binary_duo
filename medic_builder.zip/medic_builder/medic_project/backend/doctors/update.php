<?php
require_once "../api/db.php";
require_once "../api/response.php";

$id = $_POST["id"];
$status = $_POST["status"];

if (!$id || !$status) {
    sendJSON(false, "Missing fields");
}

$q = "UPDATE doctors SET status='$status' WHERE id='$id'";

if ($conn->query($q)) {
    sendJSON(true, "Doctor updated");
} else {
    sendJSON(false, "Failed");
}
?>
