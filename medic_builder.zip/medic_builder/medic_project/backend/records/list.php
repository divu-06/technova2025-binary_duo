<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../config.php";

$user_id = $_GET["user_id"] ?? null;

if (!$user_id) {
    http_response_code(400);
    echo json_encode(["error" => "Missing user_id"]);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM records WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);

echo json_encode([
    "status" => "success",
    "records" => $stmt->fetchAll(PDO::FETCH_ASSOC)
]);
