<?php
require_once __DIR__ . "/../config.php";
$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
$stmt = $pdo->query("SELECT * FROM appointments ORDER BY created_at DESC LIMIT 200");
echo json_encode(['appointments'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
?>
