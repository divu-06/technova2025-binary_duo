# MEDIC API Docs (Placeholder)
- /appointments
- /video_call
- /ai_symptom
- /qr
- /sos
