<?php
require_once "../api/db.php";
require_once "../api/response.php";

$user_id = $_GET["user_id"];

$result = $conn->query("SELECT * FROM reports WHERE user_id='$user_id'");

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

sendJSON(true, "Reports", $data);
?>
