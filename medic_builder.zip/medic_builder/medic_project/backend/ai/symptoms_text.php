<?php
require_once __DIR__ . "/../config.php";
$input = json_decode(file_get_contents('php://input'), true);
$symptoms = $input['symptoms'] ?? '';
if(empty($symptoms)){ http_response_code(400); echo json_encode(['error'=>'missing']); exit; }
if(OPENAI_API_KEY && OPENAI_API_KEY !== 'sk-XXXXX'){
    $payload = ["model"=>"gpt-4o-mini","messages"=>[["role"=>"user","content"=>"Symptoms: $symptoms\nSuggest 3 possible conditions, urgency, and specialist."]],"max_tokens"=>300];
    $ch = curl_init("https://api.openai.com/v1/chat/completions");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer ".OPENAI_API_KEY,"Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    $res = curl_exec($ch); curl_close($ch);
    echo $res;
} else {
    echo json_encode(["result"=>"Fallback: possible viral infection or dermatological issue depending on keywords."]);
}
?>
