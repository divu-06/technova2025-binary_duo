<?php
require_once __DIR__ . "/../config.php";
$room = 'medic_room_'.bin2hex(random_bytes(4));
$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
$stmt = $pdo->prepare("INSERT INTO video_rooms (room_name, creator_id, created_at) VALUES (?, ?, NOW())");
$stmt->execute([$room, $_POST['user_id'] ?? null]);
echo json_encode(['room'=>$room,'url'=>"https://your-daily-domain.daily.co/$room"]);
?>
