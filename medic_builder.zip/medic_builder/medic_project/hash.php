<?php
// only used to generate one hash — delete after use
echo password_hash("123456", PASSWORD_DEFAULT);
