<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../config.php";

$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'] ?? null;
$password = $data['password'] ?? null;

if (!$email || !$password) {
    echo json_encode(["error" => "Missing email/password"]);
    exit;
}

$stmt = $pdo->prepare("SELECT id, name, email, password, role FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$user){
    http_response_code(401);
    echo json_encode(["error" => "Invalid credentials"]);
    exit;
}

if(!password_verify($password, $user['password'])){
    http_response_code(401);
    echo json_encode(["error" => "Invalid password"]);
    exit;
}

echo json_encode([
    "status" => "success",
    "user" => [
        "id" => $user['id'],
        "name" => $user['name'],
        "email" => $user['email'],
        "role" => $user['role']
    ]
]);
?>
