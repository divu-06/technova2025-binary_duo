Video Call Integration:
- Placeholder for Zego / Daily WebRTC client
