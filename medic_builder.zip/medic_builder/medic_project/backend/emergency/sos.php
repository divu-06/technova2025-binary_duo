<?php
require_once __DIR__ . "/../config.php";
$in = json_decode(file_get_contents('php://input'), true);
if(empty($in['user_id']) || !isset($in['lat']) || !isset($in['lng'])){ http_response_code(400); echo json_encode(['error'=>'missing']); exit;}
$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
$stmt = $pdo->prepare("INSERT INTO sos_requests (user_id, lat, lng, note, status, created_at) VALUES (?, ?, ?, ?, 'triggered', NOW())");
$stmt->execute([$in['user_id'],$in['lat'],$in['lng'],$in['note'] ?? null]);
echo json_encode(['status'=>'ok','sos_id'=>$pdo->lastInsertId()]);
?>
