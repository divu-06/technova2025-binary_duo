<?php
require_once "../api/db.php";
require_once "../api/response.php";

$result = $conn->query("SELECT * FROM doctors");

$doctors = [];
while ($row = $result->fetch_assoc()) {
    $doctors[] = $row;
}

sendJSON(true, "Doctors loaded", $doctors);
?>
