<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . "/../config.php";

$input = json_decode(file_get_contents('php://input'), true);
$user_id = $input['user_id'] ?? null;

if(!$user_id){
    http_response_code(400);
    echo json_encode(['error'=>'missing']);
    exit;
}

$token = bin2hex(random_bytes(8));

$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);

$stmt = $pdo->prepare("INSERT INTO qr_profiles (user_id, qr_token, created_at) VALUES (?, ?, NOW())");
$stmt->execute([$user_id, $token]);

// FIXED URL FOR LOCALHOST
$profile_url = "http://localhost/medic_builder/medic_project/backend/qr/get_profile.php?token=" . $token;

// Google QR generation API
$qr_api = "https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=" . urlencode($profile_url);

echo json_encode([
    'qr_url' => $qr_api,
    'profile_url' => $profile_url,
    'token' => $token
]);
?>
