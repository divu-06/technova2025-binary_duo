<?php
require_once "../api/db.php";
require_once "../api/response.php";

$user = $_POST["user_id"];
$medicine = $_POST["medicine_id"];
$qty = $_POST["qty"];

$q = "INSERT INTO orders (user_id, medicine_id, qty, status) 
      VALUES ('$user', '$medicine', '$qty', 'pending')";

if ($conn->query($q)) {
    sendJSON(true, "Order placed");
} else {
    sendJSON(false, "Order failed");
}
?>
