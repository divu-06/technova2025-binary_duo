<?php
require_once __DIR__ . "/../config.php";
$input = json_decode(file_get_contents('php://input'), true);
$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
$stmt = $pdo->prepare("INSERT INTO prescriptions (user_id,doctor_id,prescription_json,created_at) VALUES (?,?,?,NOW())");
$stmt->execute([$input['user_id'],$input['doctor_id'],json_encode($input['medicines'] ?? [])]);
echo json_encode(['status'=>'ok','id'=>$pdo->lastInsertId()]);
?>
