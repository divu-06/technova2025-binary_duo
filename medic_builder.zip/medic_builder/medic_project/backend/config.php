<?php
// Database configuration constants
define("DB_HOST", "127.0.0.1");
define("DB_NAME", "medic_db");
define("DB_USER", "root");
define("DB_PASS", "");

// OPTIONAL: Create a PDO connection for easy usage elsewhere
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8",
        DB_USER,
        DB_PASS
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed: " . $e->getMessage()
    ]);
    exit;
}
?>
