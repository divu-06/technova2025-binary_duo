<?php 
header("Content-Type: application/json"); 
require_once __DIR__ . "/../config.php";

$data = json_decode(file_get_contents('php://input'), true);

$user_id = $data['user_id'] ?? null;
if (!$user_id){
    http_response_code(400);
    echo json_encode(['error' => 'missing user']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO records (user_id, title, description, record_date, source, created_at) VALUES (?,?,?,?,?,NOW())");
$stmt->execute([
    $user_id,
    $data['title'] ?? '',
    $data['description'] ?? '',
    $data['record_date'] ?? null,
    $data['source'] ?? null
]);

echo json_encode([
    'status' => 'success',
    'id' => $pdo->lastInsertId()
]);
