<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../config.php";

$stmt = $pdo->query("SELECT id, name, email FROM users WHERE role='patient'");
echo json_encode(["patients" => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
?>
