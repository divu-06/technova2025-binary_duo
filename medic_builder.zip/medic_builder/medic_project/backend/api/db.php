<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "medic_db";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die(json_encode([
        "status" => false,
        "message" => "Database connection failed"
    ]));
}
?>
