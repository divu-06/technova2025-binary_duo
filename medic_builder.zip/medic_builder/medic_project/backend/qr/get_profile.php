<?php
require_once __DIR__ . "/../config.php";

$token = $_GET['token'] ?? null;

if (!$token) {
    echo json_encode(["error" => "No token provided"]);
    exit;
}

// fetch qr profile entry
$stmt = $pdo->prepare("SELECT user_id FROM qr_profiles WHERE qr_token = ?");
$stmt->execute([$token]);
$qr = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$qr) {
    echo json_encode(["error" => "QR token not found"]);
    exit;
}

$user_id = $qr['user_id'];

// fetch user profile
$stmtUser = $pdo->prepare("SELECT id, name, email, phone, blood_group, allergies FROM users WHERE id = ?");
$stmtUser->execute([$user_id]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(["error" => "User not found"]);
    exit;
}

echo json_encode([
    "status" => "success",
    "profile" => $user
]);
?>
