<?php
require_once "../api/response.php";

sendJSON(true, "Video session joined", [
    "token" => uniqid("join_")
]);
?>
