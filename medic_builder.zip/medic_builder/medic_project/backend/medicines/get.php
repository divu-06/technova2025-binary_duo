<?php
require_once "../api/db.php";
require_once "../api/response.php";

$id = $_GET["id"];

$result = $conn->query("SELECT * FROM medicines WHERE id='$id'");
$data = $result->fetch_assoc();

sendJSON(true, "Loaded", $data);
?>
