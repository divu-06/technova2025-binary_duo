<?php
echo json_encode(['service'=>'MEDIC API','version'=>'0.1','time'=>date('c')]);
?>
