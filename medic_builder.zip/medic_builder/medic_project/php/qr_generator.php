<?php
// QR generator for patient medical ID
echo "qr generator placeholder";
?>
