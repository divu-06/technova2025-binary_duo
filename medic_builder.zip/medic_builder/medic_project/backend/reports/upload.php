<?php
require_once "../api/db.php";
require_once "../api/response.php";

$user_id = $_POST["user_id"];
$file = $_FILES["report"];

$target = "../../uploads/" . time() . "_" . basename($file["name"]);

if (move_uploaded_file($file["tmp_name"], $target)) {
    $path = str_replace("../../", "", $target);
    $conn->query("INSERT INTO reports (user_id, file_path) VALUES ('$user_id', '$path')");
    sendJSON(true, "Report uploaded", $path);
} else {
    sendJSON(false, "Failed to upload");
}
?>
