<?php
require_once __DIR__ . "/../config.php";
$data = json_decode(file_get_contents('php://input'), true);
$name=$data['name'] ?? ''; $email=$data['email'] ?? ''; $pass=$data['password'] ?? '';
if(!$name || !$email || !$pass) { http_response_code(400); echo json_encode(['error'=>'missing']); exit;}
$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
$stmt = $pdo->prepare("INSERT INTO users (name,email,password,created_at) VALUES (?, ?, ?, NOW())");
$stmt->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);
echo json_encode(['status'=>'ok']);
?>
