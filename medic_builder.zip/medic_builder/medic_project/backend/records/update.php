<?php
header("Content-Type: application/json");
require_once __DIR__ . "/../config.php";

$id = $_GET["id"] ?? null;
if (!$id) {
    http_response_code(400);
    echo json_encode(["error" => "Missing id"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$stmt = $pdo->prepare("
    UPDATE records
    SET title = ?, description = ?, record_date = ?, source = ?, updated_at = NOW()
    WHERE id = ?
");
$stmt->execute([
    $data["title"] ?? "",
    $data["description"] ?? "",
    $data["record_date"] ?? null,
    $data["source"] ?? null,
    $id
]);

echo json_encode(["status" => "success"]);
