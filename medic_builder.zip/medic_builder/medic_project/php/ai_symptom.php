<?php
// AI Symptom checker endpoint (text + image)
echo "ai symptom checker placeholder";
?>
